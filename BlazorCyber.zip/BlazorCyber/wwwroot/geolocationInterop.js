﻿window.geolocationInterop = {
    getCurrentPosition: function (options) {
        return new Promise((resolve, reject) => {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(position => {
                    resolve({
                        coords: {
                            latitude: position.coords.latitude,
                            longitude: position.coords.longitude
                        }
                    });
                }, reject, options);
            } else {
                reject('Geolocation is not supported by this browser.');
            }
        });
    }
};


